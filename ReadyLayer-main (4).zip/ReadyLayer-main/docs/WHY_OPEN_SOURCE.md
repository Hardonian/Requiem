# Why ReadyLayer Is Open Source

**Governance tooling for AI-generated code must be inspectable, modifiable, and trustworthy. Open source is the only model that makes this possible.**

---

## The Core Argument

AI-generated code presents a **trust problem** that proprietary solutions cannot solve:

1. **AI writes code faster than humans can review it**
2. **That code must be governed for safety (security, tests, docs)**
3. **Governance decisions block or allow production deployments**
4. **Teams must trust those decisions are correct and unbiased**

**The dilemma:** How do you trust a black-box system to make deployment decisions?

**The answer:** You don't. You inspect the governance logic yourself.

**The mechanism:** Open source.

---

## Why Proprietary Governance Fails

### 1. Opaque Decision-Making

**Problem:** You deploy ReadyLayer. It blocks your PR. You don't know why the decision was made.

**Proprietary response:** "Our advanced AI detected a security issue. Trust us."

**What you can't verify:**
- Was the detection accurate, or a false positive?
- What rule triggered the block?
- Is the vendor prioritizing their metrics (e.g., "catch more issues to look good") over your velocity?
- Can you reproduce the decision locally?

**OSS response:** Read the code. The security rule is in `services/review-guard/rules/sql-injection.ts`. The decision logic is in `services/policy-engine/evaluator.ts`. Reproduce it locally. Modify the rule if needed.

### 2. Vendor Lock-In

**Problem:** Your governance system becomes critical infrastructure. Switching vendors requires retraining your team, rewriting policies, and risking service interruption.

**Proprietary response:** "Don't worry, we'll keep your data safe. (But you can't export your policies or decision history in a usable format.)"

**What you can't do:**
- Export your policy configurations to a competitor
- Run governance locally when the vendor has an outage
- Fork the project if the vendor raises prices 10x

**OSS response:** Apache 2.0 license. Fork anytime. Export everything. Run anywhere. No hostages.

### 3. Unauditable "AI Magic"

**Problem:** Governance tools increasingly use LLMs to make decisions. Those decisions must be auditable for compliance (SOC 2, ISO 27001, etc.).

**Proprietary response:** "Our model is proprietary. Trust the output."

**What auditors ask:**
- Can you explain how this decision was reached?
- Can you prove the same input would produce the same output tomorrow?
- Can you show me the model training data?

**What you can't answer:** Any of the above.

**OSS response:** Deterministic policy engine. Same input + same policy = same output. LLM calls are optional enrichment, not decision-making. All evidence bundles include policy hash, input hash, and decision trace. Auditors can inspect the code themselves.

---

## Why Open Source Governance Succeeds

### 1. Inspectability

**Governance decisions must be defensible in audits.** Open source makes the logic inspectable:

- Security rules are in `services/review-guard/rules/`
- Policy evaluation is in `services/policy-engine/evaluator.ts`
- Test coverage logic is in `services/test-engine/`
- Decision hashing is in `lib/hash.ts`

**No magic. No mystery. No "trust us."**

If ReadyLayer blocks your PR, you can:
1. Read the rule that triggered
2. Understand why it triggered
3. Verify it's correct
4. Modify it if wrong
5. Contribute the fix back

### 2. Modifiability

**Every organization has unique risk tolerance.** Open source allows adaptation:

- Too many false positives? Adjust the rule.
- Need a custom security check? Add it.
- Different test coverage threshold? Change the config.
- Want to integrate with internal tools? Fork and extend.

Proprietary tools force you into **their** risk model. OSS lets you define yours.

### 3. Portability

**Governance is critical infrastructure.** Open source ensures you're never stranded:

- Run on AWS, GCP, Azure, on-prem, or localhost
- No vendor outages block your deployments
- No pricing changes force budget reallocation
- No acquisition by a competitor kills the product

**You control the runtime. Forever.**

### 4. Community Trust

**Governance tooling benefits from collective scrutiny.** Open source enables:

- Security researchers auditing detection logic
- Compliance experts reviewing audit trails
- Developers contributing policy templates
- Users catching bugs before you hit them

Proprietary tools have internal QA teams. OSS has the internet.

---

## Common Objections (Answered)

### "If it's free, how do you make money?"

**Answer:** Apache 2.0 doesn't mean "no revenue." It means "no lock-in."

We offer **Enterprise Cloud**, a managed hosting service for teams that prefer not to run infrastructure. The OSS version is fully functional. Enterprise Cloud is operational convenience, not superior features.

Think: **GitLab** (OSS + managed hosting), not **freemium SaaS** (crippled free tier).

### "Won't competitors clone your code?"

**Answer:** Yes, and that's the point.

If someone builds a better hosted version of ReadyLayer, users win. Competition validates that the framework is valuable. We compete on execution, not source code secrecy.

**Precedent:** Linux didn't die because companies could fork it. It thrived because the best implementations won users.

### "Open source projects get abandoned. What if you quit?"

**Answer:** Apache 2.0 ensures the project outlives the founders.

If we stop maintaining ReadyLayer:
- The community can fork and continue
- Your self-hosted instances keep running
- No license servers to call home

Contrast with proprietary tools:
- Vendor shuts down → software stops working
- Vendor gets acquired → product gets killed
- Vendor pivots → you're on legacy version forever

**OSS is vendor-death-resistant.**

### "How do I know this won't become 'open core' bait?"

**Answer:** Read [OSS_VS_ENTERPRISE_BOUNDARY.md](./OSS_VS_ENTERPRISE_BOUNDARY.md).

We've documented explicit boundaries:
- Core governance logic stays OSS forever
- No telemetry, no account requirements, no degradation
- Community oversight with fork-friendly license

If we violate those boundaries, fork the project. The license guarantees you that right.

---

## Philosophical Foundations

### 1. Governance Requires Transparency

**Principle:** If you can't inspect it, you can't trust it.

Governance decisions have real consequences:
- Blocked PRs delay features
- Missed security issues cause breaches
- False positives waste developer time

**Those decisions must be auditable.** Proprietary governance is governance by faith. OSS governance is governance by verification.

### 2. AI-Generated Code Demands Scrutiny

**Principle:** Code you didn't write yourself requires extra skepticism.

AI coding assistants accelerate development, but they also introduce:
- Subtle security vulnerabilities (SQL injection, XSS)
- Untested code paths
- Outdated dependencies
- Documentation debt

**Governance tools for AI code must be held to higher standards.** You're already trusting AI to write code. Don't also trust a black box to review it.

### 3. Open Source Aligns Incentives

**Principle:** Proprietary vendors optimize for revenue. OSS optimizes for utility.

**Proprietary incentives:**
- Maximize vendor lock-in (harder to leave = more revenue)
- Upsell to "Enterprise" (gate features behind paywalls)
- Optimize metrics that look good in sales decks (vanity metrics)

**OSS incentives:**
- Maximize adoption (more users = more contributors)
- Solve real problems (utility drives usage)
- Build trust (credibility drives enterprise sales of managed hosting)

**ReadyLayer's incentive:** Be so useful that teams prefer our managed hosting over self-hosting. That only works if the OSS version is genuinely excellent.

---

## What Open Source Enables

### For Individual Developers

- **Learn by reading**: Understand how governance works
- **Contribute fixes**: Improve the tool you depend on
- **Build extensions**: Integrate with your custom workflows
- **Run locally**: Test governance rules before deploying

### For Teams

- **Audit decisions**: Verify governance logic is correct
- **Customize policies**: Adapt to your risk tolerance
- **Self-host**: No external dependencies in CI/CD
- **Fork if needed**: Escape vendor changes you disagree with

### For Enterprises

- **Compliance evidence**: Show auditors the source code
- **Vendor risk mitigation**: No single point of failure
- **Internal modifications**: Add proprietary integrations
- **Long-term confidence**: Project outlives any one company

### For the Industry

- **Shared policy templates**: Community-driven best practices
- **Security research**: Crowd-sourced vulnerability detection
- **Innovation**: Forks can experiment with new approaches
- **Standards**: Open governance models become industry norms

---

## Anti-Patterns We Avoid

### ❌ Open Core (Feature Gating)

**What it is:** "Free" version is deliberately crippled. Useful features locked behind paywall.

**Why it's bad:** Users feel baited. OSS version exists to funnel users to paid product, not to solve problems.

**How we avoid it:** Core governance logic (security, tests, docs) stays OSS. Enterprise Cloud is managed hosting, not feature unlocks. See [OSS_VS_ENTERPRISE_BOUNDARY.md](./OSS_VS_ENTERPRISE_BOUNDARY.md).

### ❌ Source-Available (Not Actually Open)

**What it is:** Code is visible but not modifiable/redistributable (e.g., "Commons Clause").

**Why it's bad:** Can't fork if vendor does something user-hostile. License can change retroactively. Not OSI-approved.

**How we avoid it:** Apache 2.0 license. Fully OSI-approved. Fork-friendly. Irrevocable.

### ❌ Rug Pull (Relicensing)

**What it is:** Start OSS, then relicense to proprietary after building user base (e.g., Elastic, MongoDB).

**Why it's bad:** Destroys community trust. Forces users to stay on old versions or pay up.

**How we avoid it:** Apache 2.0 is irrevocable for existing versions. If we relicense future versions (we won't), community can fork the last Apache 2.0 release.

### ❌ Contribution Capture (CLA Abuse)

**What it is:** Require contributors sign CLA granting company exclusive relicensing rights. Then relicense to proprietary.

**Why it's bad:** Contributors helped build OSS, then get locked out of their own work.

**How we avoid it:** No CLA. Contributions are Apache 2.0 licensed. We can't relicense without unanimous contributor consent (impossible at scale).

---

## Precedents We Follow

### GitLab: OSS + Managed Hosting

- **Model:** Fully functional OSS. Managed hosting for convenience.
- **Success:** 30M+ users. $15B valuation. OSS version still thriving.
- **Lesson:** Users choose managed hosting for convenience, not because OSS is crippled.

### Mastodon: Staunchly Open

- **Model:** No commercial hosting. Pure OSS. Community-run instances.
- **Success:** 15M+ users. Credible Twitter alternative.
- **Lesson:** Anti-commercial stance builds trust with users fleeing proprietary platforms.

### Plausible Analytics: Transparent Boundaries

- **Model:** OSS analytics. Managed hosting available. Clear feature parity.
- **Success:** Sustainable business. No user hostility.
- **Lesson:** Honesty about OSS/paid boundaries builds trust.

### Discourse: Community-Driven

- **Model:** OSS forum software. Managed hosting for teams that want it.
- **Success:** 10+ years. Thousands of deployments.
- **Lesson:** OSS-first with optional managed hosting is sustainable.

**ReadyLayer follows this playbook:** Excellent OSS + optional managed hosting.

---

## Our Commitments

We commit to:

1. **Keeping core governance logic open source forever** (see [OSS_VS_ENTERPRISE_BOUNDARY.md](./OSS_VS_ENTERPRISE_BOUNDARY.md))
2. **No telemetry or tracking in OSS** (your code, your privacy)
3. **No account requirements** (self-host without calling home)
4. **No feature degradation** (OSS won't get worse to sell Enterprise)
5. **Apache 2.0 license** (fork-friendly, irrevocable, OSI-approved)
6. **Community governance** (see [GOVERNANCE.md](./GOVERNANCE.md))

If we violate these commitments, **fork the project.** Apache 2.0 guarantees you that right.

---

## The Bottom Line

**ReadyLayer is open source because governance tooling must be trustworthy.**

You can't trust a black box to make deployment decisions. You can't audit proprietary logic. You can't verify closed-source security rules. You can't escape vendor lock-in without source code.

Open source solves all of these problems.

**We're open source by necessity, not marketing.**

Governance for AI-generated code demands transparency. Open source delivers it.

---

## Questions?

- **Philosophy questions:** opensource@readylayer.io
- **Boundary questions:** See [OSS_VS_ENTERPRISE_BOUNDARY.md](./OSS_VS_ENTERPRISE_BOUNDARY.md)
- **Governance questions:** See [GOVERNANCE.md](./GOVERNANCE.md)
- **General questions:** GitHub Discussions

---

## Summary

ReadyLayer is open source because:

1. **Governance requires inspectability** (can't trust what you can't audit)
2. **AI code demands scrutiny** (black-box governance is unacceptable)
3. **Open source aligns incentives** (utility over lock-in)
4. **Transparency builds trust** (show, don't tell)

**This isn't a marketing strategy. It's an engineering requirement.**

Code that governs code must be open.
