# ReadyLayer Comprehensive Roadmap 2026

> **Analysis Date:** 2026-01-17
> **Overall Readiness:** 75% complete for MVP launch
> **Total Estimated Effort:** 224 hours (P0-P2 combined)

---

## Executive Summary

ReadyLayer is a production-capable platform with **critical gaps** that must be addressed before enterprise launch. The platform demonstrates strong architectural foundations (70+ database models, 23+ services, 82% test coverage) but has implementation gaps in security, integrations, and promised features.

### Key Findings

**🔴 Critical Blockers (P0):** 6 issues, ~42 hours
- Security: Secrets not redacted before LLM calls, tokens stored in plaintext
- Core Features: GitHub App installation flow missing, billing enforcement bypassed
- Marketing Claims: Cultural Artifacts™ 30-40% complete despite prominent advertising

**🟡 High Priority (P1):** 10 issues, ~54 hours
- Authorization, caching, audit logging, check-run annotations

**🟢 Medium Priority (P2):** 8 issues, ~128 hours
- Analytics dashboards, test execution sandbox, accessibility compliance

---

## Table of Contents

1. [Critical Launch Blockers (P0)](#p0-launch-blockers)
2. [High Priority Fixes (P1)](#p1-high-priority)
3. [Medium Priority Enhancements (P2)](#p2-medium-priority)
4. [Frontend Pages & UX](#frontend-pages--ux)
5. [Backend & API Gaps](#backend--api)
6. [Security & Hardening](#security--hardening)
7. [Logging & Analytics](#logging--analytics)
8. [Integrations](#integrations)
9. [Moat Strengthening](#moat-strengthening)
10. [Implementation Timeline](#implementation-timeline)

---

## P0: Launch Blockers

**Total Effort:** 42 hours | **Must Fix Before Production**

### 1. Secrets Redaction - Not Enforced ⚠️ CRITICAL

**Status:** Security feature claimed but not implemented
**Impact:** API keys, tokens, passwords sent to LLM providers
**Risk:** GDPR violation, customer data exposure, reputation damage

**Evidence:**
```typescript
// services/review-guard/async-processor.ts:157
const redactedCode = content; // TODO: Add redaction
```

**Files Affected:**
- `services/review-guard/async-processor.ts` - Main code review LLM calls
- `services/test-engine/index.ts` - Test generation LLM calls
- `services/doc-sync/index.ts` - Documentation LLM calls

**Solution:**
```typescript
import { redactSecrets } from '@/lib/secrets/redaction';

// BEFORE LLM call:
const safeCode = redactSecrets(userCode);
const safePrompt = constructPrompt(safeCode); // Never use original
```

**Action Items:**
1. ✅ Import `redactSecrets()` utility (already exists at `lib/secrets/redaction.ts`)
2. ✅ Apply to all code passed to LLM services
3. ✅ Add runtime assertion: `if (containsSecretPattern(prompt)) throw new Error()`
4. ✅ Add redaction metrics to observability dashboard
5. ✅ Update E2E test at `e2e/secrets-redaction.spec.ts:338` to verify enforcement

**Effort:** 4 hours
**Priority:** P0 - Security Critical
**Reference:** `ARCHITECTURE-GAP-ANALYSIS.md` - Gap A2

---

### 2. Token Encryption at Rest ⚠️ CRITICAL

**Status:** Comment says "encrypted" but tokens stored in plaintext
**Impact:** Database breach exposes all GitHub installation tokens
**Risk:** Violates GitHub App security requirements, customer repositories at risk

**Evidence:**
```prisma
// prisma/schema.prisma:131
model Installation {
  accessToken      String  @db.Text // Encrypted (comment only!)
  tokenEncrypted   Boolean @default(false) // Always false in practice
}
```

```typescript
// workers/webhook-processor.ts:38
const accessToken = installation.accessToken; // Plaintext retrieval
```

**Solution:**
```typescript
// Use existing encryption utility
import { encrypt, decrypt } from '@/lib/secrets/encrypt';

// On installation creation:
const encryptedToken = encrypt(accessToken);
await prisma.installation.create({
  data: {
    accessToken: encryptedToken,
    tokenEncrypted: true
  }
});

// On token retrieval:
const encrypted = installation.accessToken;
const plaintext = installation.tokenEncrypted
  ? decrypt(encrypted)
  : encrypted; // Backward compat during migration
```

**Action Items:**
1. ✅ Create getters/setters on Installation model
2. ✅ Create database migration to encrypt existing tokens
3. ✅ Update all token access points (9 files)
4. ✅ Verify `tokenEncrypted` flag after migration
5. ✅ Add rotation endpoint: `POST /api/v1/installations/[id]/rotate-token`

**Files to Update:**
- `workers/webhook-processor.ts:38`
- `integrations/github/api-client.ts:44`
- `app/api/webhooks/github/route.ts:127`
- 6 more service files

**Effort:** 4 hours
**Priority:** P0 - Security Critical
**Reference:** `ARCHITECTURE-GAP-ANALYSIS.md` - Gap A1

---

### 3. GitHub App Installation Flow - Missing ⚠️ CRITICAL

**Status:** Product unusable - users cannot connect repositories
**Impact:** Core functionality non-functional
**Risk:** Cannot demo to customers, zero user adoption

**Evidence:**
- `app/dashboard/repos/connect/page.tsx` - Incomplete UI
- No OAuth callback handler for GitHub App installation
- Webhook handlers exist but no way to trigger them

**Current User Journey:**
1. User clicks "Connect Repository" → 🔴 **Dead end**
2. No GitHub App installation redirect
3. No callback to save installation
4. Webhooks never fire

**Solution:**

**Step 1:** Create installation redirect
```typescript
// app/api/integrations/github/install/route.ts
export async function GET(req: Request) {
  const installUrl = `https://github.com/apps/${GITHUB_APP_SLUG}/installations/new`;
  const state = generateSecureState(req.userId);
  return redirect(`${installUrl}?state=${state}`);
}
```

**Step 2:** Create callback handler
```typescript
// app/api/integrations/github/callback/route.ts
export async function GET(req: Request) {
  const { installation_id, state } = req.query;

  // Verify state token
  verifyState(state, req.userId);

  // Save installation
  await prisma.installation.create({
    data: {
      providerId: installation_id,
      provider: 'github',
      organizationId: req.user.organizationId,
      status: 'active'
    }
  });

  return redirect('/dashboard/repos?success=true');
}
```

**Step 3:** Update connect page
```typescript
// app/dashboard/repos/connect/page.tsx
<Button onClick={() => window.location.href = '/api/integrations/github/install'}>
  Install GitHub App
</Button>
```

**Action Items:**
1. ✅ Create installation redirect endpoint
2. ✅ Create OAuth callback handler
3. ✅ Update UI with installation button
4. ✅ Add installation status display
5. ✅ Add repository selection UI (after installation)
6. ✅ Add health check: verify webhook delivery

**Effort:** 6 hours
**Priority:** P0 - Core Feature
**Reference:** `docs/GIT-PROVIDER-ROADMAP.md` - Phase 1, Section 2.1

---

### 4. Billing Enforcement in Webhooks ⚠️ CRITICAL

**Status:** Webhook-triggered reviews bypass billing limits
**Impact:** Users can exceed LLM budget via PR webhooks
**Risk:** Unlimited cost exposure, billing disputes

**Evidence:**
```typescript
// app/api/v1/reviews/route.ts:103
await checkBillingLimits(organizationId); // ✅ Present

// workers/webhook-processor.ts - Missing!
async function processPREvent(event) {
  // ❌ No billing check
  const review = await createReview(event.pullRequest);
  await enrichWithLLM(review); // Costs money!
}
```

**Exploit Scenario:**
1. User exceeds LLM budget via API → Blocked ✅
2. User opens 100 PRs via GitHub → All processed ❌
3. Organization charged for 100x LLM calls

**Solution:**
```typescript
// workers/webhook-processor.ts
import { checkBillingLimits } from '@/lib/billing-middleware';

async function processPREvent(event) {
  const { organizationId } = event.installation;

  // Check budget BEFORE processing
  const { allowed, reason } = await checkBillingLimits(organizationId);

  if (!allowed) {
    await createReview({
      ...event.pullRequest,
      status: 'blocked',
      blockReason: reason // "LLM_BUDGET_EXCEEDED"
    });

    await notifyOrganization({
      type: 'budget_exceeded',
      message: 'Upgrade plan to continue reviews'
    });

    return; // Don't process
  }

  // Proceed with review
  await enrichWithLLM(review);
}
```

**Action Items:**
1. ✅ Add `checkBillingLimits()` call in webhook processor
2. ✅ Return 403 with clear error message
3. ✅ Send notification to org admins
4. ✅ Add test: `e2e/billing-webhook-enforcement.spec.ts`
5. ✅ Add metrics: `webhook_billing_blocks_total`

**Effort:** 2 hours
**Priority:** P0 - Cost Control
**Reference:** `ARCHITECTURE-GAP-ANALYSIS.md` - Gap C1

---

### 5. Row-Level Security (RLS) Policies ⚠️ CRITICAL

**Status:** No database-level tenant isolation
**Impact:** Application bug could leak data across organizations
**Risk:** SOC2/GDPR compliance failure, lawsuit exposure

**Evidence:**
```sql
-- prisma/schema.prisma - No RLS policies defined
-- All isolation via application WHERE clauses

-- Example vulnerable query:
SELECT * FROM "Review" WHERE id = $1;
-- ❌ Missing: AND "organizationId" = $currentOrgId
```

**Current Risk:**
- Single missing WHERE clause → full data breach
- No defense-in-depth
- Auditors will flag this immediately

**Solution:**

**Step 1:** Enable RLS on Supabase
```sql
-- Enable RLS on all tenant-scoped tables
ALTER TABLE "Repository" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Review" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Test" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Doc" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Violation" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "CostTracking" ENABLE ROW LEVEL SECURITY;
```

**Step 2:** Create helper function
```sql
CREATE OR REPLACE FUNCTION is_org_member(org_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM "OrganizationMember"
    WHERE "organizationId" = org_id
      AND "userId" = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

**Step 3:** Add policies
```sql
-- Example for Repository table
CREATE POLICY "Users can only access repositories in their organization"
  ON "Repository"
  FOR ALL
  USING (is_org_member("organizationId"));

-- Repeat for all tenant-scoped tables
```

**Action Items:**
1. ✅ Enable RLS on 15 tenant-scoped tables
2. ✅ Create `is_org_member()` helper function
3. ✅ Add SELECT/INSERT/UPDATE/DELETE policies
4. ✅ Test cross-tenant access prevention
5. ✅ Run tenant isolation E2E tests
6. ✅ Document RLS patterns in `docs/SECURITY.md`

**Effort:** 6 hours
**Priority:** P0 - Compliance Critical
**Reference:** `ARCHITECTURE-GAP-ANALYSIS.md` - Gap B1

---

### 6. Cultural Artifacts Implementation ⚠️ CRITICAL

**Status:** 30-40% complete, heavily marketed with ™ symbols
**Impact:** Marketing claims don't match reality
**Risk:** Customer disappointment, fraud allegations, refund requests

**Evidence from REALITY_GAPS.md:**

**Merge Confidence Certificates™:**
```typescript
// services/cultural-artifacts/index.ts:118-122
const gates = {
  reviewGuard: true, // ✅ Works
  testEngine: false, // ❌ Would check test engine results
  docSync: false,    // ❌ Would check doc sync results
  policyEngine: true // ✅ Works
};
```

**Readiness Score™:**
```typescript
// services/cultural-artifacts/index.ts:164-170
const policyCompliance = 0.9; // ❌ Placeholder
const testCoverage = 0.85;    // ❌ Placeholder
const docSync = 0.9;          // ❌ Placeholder
```

**AI Risk Exposure Index™:**
- 0% implemented
- No calculation method found
- Advertised in marketing materials

**Decision Point:**

**Option A: Complete Implementation** (20 hours)
1. ✅ Implement actual metric aggregation
2. ✅ Wire test-engine gates
3. ✅ Wire doc-sync gates
4. ✅ Persist certificates to database
5. ✅ Build `/api/v1/cultural-artifacts/certificate/[reviewId]`
6. ✅ Create AI Risk Exposure calculation service

**Option B: Downgrade Claims** (1 hour)
1. ✅ Remove ™ symbols from UI
2. ✅ Add "Beta" labels
3. ✅ Update marketing to "Coming Soon"
4. ✅ Add disclaimer in docs

**Recommendation:** Option A for competitive differentiation, or Option B for honest MVP

**Effort:** 20 hours (Option A) or 1 hour (Option B)
**Priority:** P0 - Product Integrity
**Files:**
- `services/cultural-artifacts/index.ts` - Main implementation
- `app/dashboard/reviews/[reviewId]/certificate/page.tsx` - UI
- `app/api/v1/cultural-artifacts/` - API routes

---

## P1: High Priority

**Total Effort:** 54 hours | **Fix Within 2 Weeks**

### 1. Resource-Level Authorization (3 hours)

**Problem:** No verification that user can access specific resources

**Example Vulnerability:**
```typescript
// app/api/v1/reviews/[reviewId]/route.ts
export async function GET(req, { params }) {
  const review = await prisma.review.findUnique({
    where: { id: params.reviewId }
  });
  // ❌ Missing: Does user have access to this review's repository?
  return Response.json(review);
}
```

**Solution:**
```typescript
// lib/authz.ts
export async function canAccessRepository(userId: string, repoId: string) {
  const member = await prisma.organizationMember.findFirst({
    where: {
      userId,
      organization: {
        repositories: { some: { id: repoId } }
      }
    }
  });
  return !!member;
}

// In route handler:
const review = await prisma.review.findUnique({ where: { id } });
if (!await canAccessRepository(req.userId, review.repositoryId)) {
  return new Response('Forbidden', { status: 403 });
}
```

**Files to Update:** 12 `[id]` route handlers

---

### 2. API Key Expiration Enforcement (2 hours)

**Problem:** Expired keys not rejected, no rotation mechanism

**Solution:**
```typescript
// lib/auth.ts - Update authenticateApiKey()
const key = await prisma.apiKey.findFirst({
  where: { hashedKey, revokedAt: null }
});

if (!key) return null;

// Add expiration check
if (key.expiresAt && new Date() > key.expiresAt) {
  await auditLog({
    action: 'api_key_expired_used',
    keyId: key.id,
    userId: key.userId
  });
  return null;
}
```

**New Endpoint:**
```typescript
// POST /api/v1/api-keys/[keyId]/rotate
export async function POST(req, { params }) {
  const newKey = generateSecureKey();
  await prisma.apiKey.update({
    where: { id: params.keyId },
    data: {
      hashedKey: hashKey(newKey),
      expiresAt: addYears(new Date(), 1)
    }
  });
  return Response.json({ key: newKey }); // Show once
}
```

---

### 3. Audit Logging Consistency (4 hours)

**Problem:** Audit log model exists but not used consistently

**Missing Audit Logs:**
- API key creation/deletion
- Repository connection/removal
- Billing tier changes
- Review manual overrides
- Policy pack updates

**Solution:**
```typescript
// lib/audit.ts
export async function auditLog(params: {
  action: string;
  userId: string;
  organizationId: string;
  resourceType?: string;
  resourceId?: string;
  metadata?: Record<string, any>;
  ipAddress?: string;
}) {
  return prisma.auditLog.create({
    data: {
      ...params,
      timestamp: new Date(),
      // Add cryptographic chaining
      previousHash: await getLastAuditHash(params.organizationId),
      hash: computeHash(params)
    }
  });
}
```

**Add to all write operations:**
```typescript
// Example: API key creation
await prisma.apiKey.create({ ... });
await auditLog({
  action: 'api_key_created',
  userId: req.userId,
  organizationId: req.user.organizationId,
  resourceType: 'ApiKey',
  resourceId: newKey.id,
  ipAddress: req.ip
});
```

---

### 4. Cost Tracking Consistency (3 hours)

**Problem:** LLM cost calculated but not always persisted

**Solution:**
```typescript
// lib/billing/cost-tracking.ts
export async function trackCost(params: {
  organizationId: string;
  service: 'llm' | 'embedding' | 'storage';
  provider: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
  costUsd: number;
  requestId: string; // For deduplication
}) {
  return prisma.costTracking.upsert({
    where: { requestId: params.requestId },
    update: {}, // Idempotent
    create: params
  });
}

// In LLM service after every call:
const cost = calculateCost(response.usage);
await trackCost({
  organizationId,
  service: 'llm',
  provider: 'openai',
  model: 'gpt-4',
  ...response.usage,
  costUsd: cost,
  requestId: response.id
});
```

**Add cost alerting:**
```typescript
// Check thresholds after tracking
const monthlyTotal = await getMonthlySpend(organizationId);
const limit = organization.llmBudgetCents / 100;

if (monthlyTotal >= limit * 0.8) {
  await notify({
    type: 'budget_warning',
    threshold: '80%',
    current: monthlyTotal,
    limit
  });
}
```

---

### 5. LLM Response Caching (4 hours)

**Problem:** Cache utility exists but not used in LLM service

**Current:**
```typescript
// services/llm/index.ts:11-15
import { generateCacheKey, getCachedResponse, setCachedResponse } from '@/lib/cache/llm-cache';
// ❌ But never called!
```

**Solution:**
```typescript
// services/llm/index.ts
export async function complete(prompt: string, options: LLMOptions) {
  const cacheKey = generateCacheKey(prompt, options);

  // Check cache
  const cached = await getCachedResponse(cacheKey);
  if (cached) {
    metrics.increment('llm.cache.hit');
    return cached;
  }

  metrics.increment('llm.cache.miss');

  // Call LLM
  const response = await provider.complete(prompt, options);

  // Cache result (TTL: 7 days)
  await setCachedResponse(cacheKey, response, { ttl: 604800 });

  return response;
}
```

**Add cache warming:**
```typescript
// Warm cache with common prompts on startup
const commonPrompts = [
  'Analyze security vulnerabilities in this code:',
  'Generate unit tests for:',
  'Verify documentation consistency:'
];

for (const prefix of commonPrompts) {
  // Pre-warm on deploy
}
```

---

### 6. Per-Organization Rate Limiting (6 hours)

**Problem:** Only IP-based rate limiting, no per-org limits

**Solution:**
```typescript
// lib/rate-limiting/org-limiter.ts
import { RateLimiter } from 'rate-limiter-flexible';

const orgLimiter = new RateLimiter({
  storeClient: redis,
  keyPrefix: 'rl:org',
  points: 1000, // 1000 requests
  duration: 3600 // per hour
});

export async function checkOrgRateLimit(orgId: string) {
  try {
    await orgLimiter.consume(orgId);
    return { allowed: true };
  } catch (err) {
    return {
      allowed: false,
      retryAfter: Math.ceil(err.msBeforeNext / 1000)
    };
  }
}

// In middleware:
const { allowed, retryAfter } = await checkOrgRateLimit(req.user.organizationId);
if (!allowed) {
  return new Response('Rate limit exceeded', {
    status: 429,
    headers: {
      'X-RateLimit-Retry-After': retryAfter.toString(),
      'X-RateLimit-Limit': '1000',
      'X-RateLimit-Remaining': '0'
    }
  });
}
```

**Add tier-based limits:**
```typescript
const limits = {
  free: { points: 100, duration: 3600 },
  pro: { points: 1000, duration: 3600 },
  enterprise: { points: 10000, duration: 3600 }
};

const limiter = new RateLimiter(limits[organization.tier]);
```

---

### 7. GitHub Check-Run Annotations (4 hours)

**Problem:** Summary-only status checks, no line-level comments

**Current UX:**
- PR gets status check: "15 issues found" ✅
- User clicks → sees generic message ❌
- No inline code comments ❌

**Desired UX:**
- PR gets check-run with annotations ✅
- Line 42: "SQL injection vulnerability" ✅
- Inline code suggestions ✅

**Solution:**
```typescript
// integrations/github/api-client.ts
export async function createCheckRun(params: {
  repositoryId: string;
  commitSha: string;
  name: string;
  status: 'queued' | 'in_progress' | 'completed';
  conclusion?: 'success' | 'failure' | 'neutral';
  annotations?: Array<{
    path: string;
    startLine: number;
    endLine: number;
    annotationLevel: 'notice' | 'warning' | 'failure';
    message: string;
    title: string;
  }>;
}) {
  return octokit.checks.create({
    owner: repo.owner,
    repo: repo.name,
    head_sha: params.commitSha,
    name: params.name,
    status: params.status,
    conclusion: params.conclusion,
    output: {
      title: 'ReadyLayer Code Review',
      summary: `Found ${params.annotations.length} issues`,
      annotations: params.annotations.slice(0, 50) // GitHub limit
    }
  });
}

// In webhook processor:
await createCheckRun({
  repositoryId,
  commitSha: pr.head.sha,
  name: 'ReadyLayer Review',
  status: 'completed',
  conclusion: review.isBlocked ? 'failure' : 'success',
  annotations: review.violations.map(v => ({
    path: v.file,
    startLine: v.startLine,
    endLine: v.endLine,
    annotationLevel: v.severity === 'critical' ? 'failure' : 'warning',
    message: v.message,
    title: v.ruleId
  }))
});
```

**GitHub Limits:**
- Max 50 annotations per check-run
- If >50 issues, link to dashboard for full list

---

### 8. Deterministic Governance (8 hours)

**Problem:** Claims determinism but uses temperature > 0

**Solution Options:**

**Option A: Full Determinism** (8 hours)
```typescript
// services/llm/index.ts
const response = await openai.chat.completions.create({
  model: 'gpt-4',
  temperature: 0, // ← Set to 0
  messages,
  // Add result caching
  seed: hashInput(messages) // OpenAI seed for determinism
});
```

**Option B: Split Signals** (4 hours)
```typescript
interface ReviewResult {
  deterministicScore: {
    static_analysis: number; // AST parsing, regex
    complexity: number;
    security_patterns: number;
  };
  aiEnrichment: {
    semantic_understanding: string; // Temperature 0.7, marked as probabilistic
    suggested_fixes: string[];
    confidence: number;
  };
}
```

**Option C: Update Messaging** (1 hour)
- Change "deterministic" → "reproducible static analysis"
- Add "AI-enriched insights may vary"
- Clearly separate static vs AI signals

**Recommendation:** Option B for best of both worlds

---

### 9. Cryptographic Audit Chain (6 hours)

**Problem:** Schema supports chaining, not implemented

**Current Schema:**
```prisma
model AuditLog {
  id           String   @id @default(cuid())
  previousHash String?  // ← Not set
  hash         String?  // ← Not set
  signature    String?  // ← Not set
}
```

**Solution:**
```typescript
// lib/audit.ts
import crypto from 'crypto';

async function getLastAuditHash(orgId: string): Promise<string | null> {
  const last = await prisma.auditLog.findFirst({
    where: { organizationId: orgId },
    orderBy: { createdAt: 'desc' },
    select: { hash: true }
  });
  return last?.hash || null;
}

function computeHash(entry: AuditLogEntry, previousHash: string | null): string {
  const data = JSON.stringify({
    action: entry.action,
    userId: entry.userId,
    resourceId: entry.resourceId,
    timestamp: entry.timestamp,
    previousHash
  });
  return crypto.createHash('sha256').update(data).digest('hex');
}

export async function auditLog(entry: AuditLogEntry) {
  const previousHash = await getLastAuditHash(entry.organizationId);
  const hash = computeHash(entry, previousHash);

  return prisma.auditLog.create({
    data: {
      ...entry,
      previousHash,
      hash,
      signature: signHash(hash) // Optional: HMAC with secret key
    }
  });
}

export async function verifyAuditChain(orgId: string): Promise<boolean> {
  const logs = await prisma.auditLog.findMany({
    where: { organizationId: orgId },
    orderBy: { createdAt: 'asc' }
  });

  for (let i = 0; i < logs.length; i++) {
    const expected = computeHash(logs[i], logs[i].previousHash);
    if (logs[i].hash !== expected) {
      return false; // Tampering detected
    }
  }

  return true;
}
```

**Add verification endpoint:**
```typescript
// GET /api/v1/audit/verify
export async function GET(req: Request) {
  const isValid = await verifyAuditChain(req.user.organizationId);
  return Response.json({
    valid: isValid,
    message: isValid ? 'Audit trail intact' : 'Tampering detected'
  });
}
```

---

### 10. GitLab/Bitbucket Integration Verification (16 hours)

**Problem:** Code exists but not verified to work end-to-end

**Files Exist:**
- `integrations/gitlab/webhook.ts` ✅
- `integrations/gitlab/api-client.ts` ✅
- `integrations/bitbucket/webhook.ts` ✅
- `integrations/bitbucket/api-client.ts` ✅

**Missing:**
- OAuth flow testing
- Status update verification
- Webhook signature validation audit
- E2E test coverage

**Action Items:**
1. ✅ Test GitLab OAuth flow (4 hours)
2. ✅ Test Bitbucket OAuth flow (4 hours)
3. ✅ Verify status updates appear in UI (2 hours)
4. ✅ Add E2E tests for both providers (4 hours)
5. ✅ Document setup in `docs/integrations/`
6. ✅ Add to provider selection UI

**Reference:** `docs/GIT-PROVIDER-ROADMAP.md` - Phase 1

---

## P2: Medium Priority

**Total Effort:** 128 hours | **Fix Within 4 Weeks**

### 1. Test Execution Sandbox (24 hours)

**Problem:** Tests generated but never verified

**Evidence:**
- `services/test-engine/index.ts` - Generates test code ✅
- `services/test-engine/executor.ts` - Stub implementation ❌
- No Docker integration ❌

**Impact:** Users may receive broken tests, cannot prove correctness

**Solution:**

**Phase 1: Docker Executor** (16 hours)
```typescript
// services/test-engine/executor.ts
import Docker from 'dockerode';

export async function executeTests(params: {
  code: string;
  tests: string;
  language: 'typescript' | 'python' | 'go';
  timeout: number; // Max 5 minutes
}): Promise<ExecutionResult> {
  const docker = new Docker();

  // Create container with resource limits
  const container = await docker.createContainer({
    Image: `readylayer/test-runner-${params.language}:latest`,
    Cmd: ['npm', 'test'], // or pytest, go test
    HostConfig: {
      Memory: 512 * 1024 * 1024, // 512MB
      NanoCpus: 1000000000, // 1 CPU
      NetworkMode: 'none' // No network access
    },
    Env: [
      'NODE_ENV=test',
      'CI=true'
    ]
  });

  // Copy files
  await container.putArchive(createTarball({
    'src/index.ts': params.code,
    'src/index.test.ts': params.tests,
    'package.json': generatePackageJson()
  }), { path: '/app' });

  // Start and wait
  await container.start();

  const result = await container.wait({ condition: 'not-running' });
  const logs = await container.logs({ stdout: true, stderr: true });

  await container.remove();

  return {
    exitCode: result.StatusCode,
    stdout: logs.toString(),
    passed: result.StatusCode === 0
  };
}
```

**Phase 2: Result Validation** (4 hours)
```typescript
// After execution:
const execution = await executeTests({ code, tests });

await prisma.test.update({
  where: { id: testRecord.id },
  data: {
    executed: true,
    executionStatus: execution.passed ? 'passed' : 'failed',
    executionLogs: execution.stdout,
    validated: true
  }
});

// Only return tests that pass validation
if (!execution.passed) {
  await regenerateTests(testRecord);
}
```

**Phase 3: Docker Images** (4 hours)
```dockerfile
# docker/test-runner-typescript/Dockerfile
FROM node:20-alpine
WORKDIR /app
RUN npm install -g vitest
COPY --chown=node:node . .
USER node
CMD ["npm", "test"]
```

**Reference:** `ARCHITECTURE-GAP-ANALYSIS.md` - Gap E1

---

### 2. RAG/Vector Search (8 hours)

**Problem:** RAG infrastructure exists but disabled by default

**Evidence:**
- `lib/rag/store.ts` - Exists ✅
- `lib/rag/providers/embeddings.ts` - OpenAI embeddings work ✅
- Default: `RAG_ENABLED=false` ❌
- No pgvector integration ❌

**Solution:**

**Step 1: Enable pgvector** (2 hours)
```sql
-- Migration: enable_pgvector.sql
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE document_embeddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID NOT NULL,
  chunk_index INTEGER NOT NULL,
  content TEXT NOT NULL,
  embedding vector(1536), -- OpenAI embedding dimension
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(document_id, chunk_index)
);

CREATE INDEX ON document_embeddings USING ivfflat (embedding vector_cosine_ops)
  WITH (lists = 100);
```

**Step 2: Implement vector store** (4 hours)
```typescript
// lib/rag/store.ts
export async function storeDocument(params: {
  documentId: string;
  content: string;
  metadata: Record<string, any>;
}) {
  const chunks = chunkDocument(params.content, { maxTokens: 512 });

  for (let i = 0; i < chunks.length; i++) {
    const embedding = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: chunks[i]
    });

    await prisma.$executeRaw`
      INSERT INTO document_embeddings (document_id, chunk_index, content, embedding, metadata)
      VALUES (${params.documentId}, ${i}, ${chunks[i]}, ${embedding.data[0].embedding}, ${params.metadata}::jsonb)
      ON CONFLICT (document_id, chunk_index) DO UPDATE
        SET embedding = EXCLUDED.embedding
    `;
  }
}

export async function searchSimilar(query: string, limit = 5): Promise<SearchResult[]> {
  const queryEmbedding = await openai.embeddings.create({
    model: 'text-embedding-3-small',
    input: query
  });

  const results = await prisma.$queryRaw`
    SELECT
      document_id,
      content,
      metadata,
      1 - (embedding <=> ${queryEmbedding.data[0].embedding}::vector) AS similarity
    FROM document_embeddings
    ORDER BY embedding <=> ${queryEmbedding.data[0].embedding}::vector
    LIMIT ${limit}
  `;

  return results;
}
```

**Step 3: Enable by default** (2 hours)
```typescript
// .env
RAG_ENABLED=true

// Indexing pipeline
export async function indexRepository(repoId: string) {
  const files = await getRepositoryFiles(repoId);

  for (const file of files) {
    await storeDocument({
      documentId: file.id,
      content: file.content,
      metadata: {
        repositoryId: repoId,
        path: file.path,
        language: file.language
      }
    });
  }
}
```

**Reference:** `ARCHITECTURE-GAP-ANALYSIS.md` - Gap F1

---

### 3. Analytics Dashboard (16 hours)

**Problem:** No user-facing analytics, valuable insights hidden

**Missing Metrics:**
- Run success/failure trends
- Time to first signal (performance KPI)
- Blocked PRs saved (value demonstration)
- Cost per repository (cost control)
- Finding severity distribution (risk profile)
- Model performance comparison (governance)

**Solution:**

**Page 1: Overview Dashboard** (8 hours)
```typescript
// app/dashboard/analytics/overview/page.tsx
export default function AnalyticsOverview() {
  const { data } = useQuery({
    queryKey: ['analytics', 'overview', dateRange],
    queryFn: () => fetch('/api/v1/analytics/overview').then(r => r.json())
  });

  return (
    <>
      {/* KPI Cards */}
      <Grid cols={4}>
        <MetricCard
          title="Total Reviews"
          value={data.totalReviews}
          trend={data.reviewsTrend}
          icon={<CheckCircle />}
        />
        <MetricCard
          title="Blocked PRs"
          value={data.blockedPRs}
          trend={data.blockedTrend}
          icon={<Shield />}
          highlight
        />
        <MetricCard
          title="Avg Time to Signal"
          value={`${data.avgTimeToSignal}s`}
          trend={data.timeTrend}
          icon={<Clock />}
        />
        <MetricCard
          title="Total Cost"
          value={`$${data.totalCost}`}
          trend={data.costTrend}
          icon={<DollarSign />}
        />
      </Grid>

      {/* Time Series Charts */}
      <TimeSeriesChart
        title="Review Volume"
        data={data.reviewTimeSeries}
        metrics={['total', 'passed', 'blocked']}
      />

      <BarChart
        title="Finding Severity Distribution"
        data={data.severityDistribution}
        categories={['critical', 'high', 'medium', 'low', 'info']}
      />

      {/* Cost Breakdown */}
      <PieChart
        title="Cost by Service"
        data={data.costBreakdown}
        segments={['review-guard', 'test-engine', 'doc-sync']}
      />
    </>
  );
}
```

**API Endpoint** (4 hours)
```typescript
// app/api/v1/analytics/overview/route.ts
export async function GET(req: Request) {
  const { startDate, endDate } = parseQueryParams(req);
  const orgId = req.user.organizationId;

  const [
    totalReviews,
    blockedPRs,
    avgTimeToSignal,
    totalCost,
    timeSeries,
    severityDist,
    costBreakdown
  ] = await Promise.all([
    // Total reviews in period
    prisma.review.count({
      where: {
        organizationId: orgId,
        createdAt: { gte: startDate, lte: endDate }
      }
    }),

    // Blocked PRs
    prisma.review.count({
      where: {
        organizationId: orgId,
        isBlocked: true,
        createdAt: { gte: startDate, lte: endDate }
      }
    }),

    // Avg time to first signal
    prisma.$queryRaw`
      SELECT AVG(
        EXTRACT(EPOCH FROM (first_signal_at - created_at))
      ) as avg_seconds
      FROM "Review"
      WHERE organization_id = ${orgId}
        AND created_at BETWEEN ${startDate} AND ${endDate}
        AND first_signal_at IS NOT NULL
    `,

    // Total cost
    prisma.costTracking.aggregate({
      where: {
        organizationId: orgId,
        createdAt: { gte: startDate, lte: endDate }
      },
      _sum: { costUsd: true }
    }),

    // Time series data (daily aggregates)
    getReviewTimeSeries(orgId, startDate, endDate),

    // Severity distribution
    prisma.violation.groupBy({
      by: ['severity'],
      where: {
        review: { organizationId: orgId },
        createdAt: { gte: startDate, lte: endDate }
      },
      _count: true
    }),

    // Cost breakdown by service
    prisma.costTracking.groupBy({
      by: ['service'],
      where: {
        organizationId: orgId,
        createdAt: { gte: startDate, lte: endDate }
      },
      _sum: { costUsd: true }
    })
  ]);

  return Response.json({
    totalReviews,
    blockedPRs,
    avgTimeToSignal: Math.round(avgTimeToSignal[0].avg_seconds),
    totalCost: totalCost._sum.costUsd || 0,
    reviewTimeSeries: timeSeries,
    severityDistribution: severityDist,
    costBreakdown: costBreakdown.map(s => ({
      service: s.service,
      cost: s._sum.costUsd
    }))
  });
}
```

**Export Functionality** (4 hours)
```typescript
// Add CSV export button
<Button onClick={async () => {
  const csv = await fetch('/api/v1/analytics/export?format=csv').then(r => r.text());
  downloadFile(csv, 'analytics-report.csv');
}}>
  Export CSV
</Button>
```

---

### 4. Governance Dashboard (16 hours)

**Problem:** Governance engine exists, no UI to visualize results

**Features Needed:**
- Variance visualization across models
- Intent drift detection
- Model performance comparison
- Governance run history

**Solution:**
```typescript
// app/dashboard/governance/variance/page.tsx
export default function VarianceDashboard() {
  return (
    <>
      <VarianceHeatmap
        title="Model Agreement Matrix"
        data={varianceData}
        models={['gpt-4', 'claude-3', 'gemini-pro']}
      />

      <TimeSeriesChart
        title="Variance Score Over Time"
        data={varianceTimeSeries}
        threshold={0.3} // Alert threshold
      />

      <ComparisonTable
        title="Model Performance"
        columns={['Model', 'Avg Confidence', 'Variance', 'Cost']}
        data={modelComparison}
      />

      <IntentDriftVisualization
        title="Intent Drift Detection"
        driftPoints={intentDrifts}
      />
    </>
  );
}
```

**Reference:** Governance engine at `services/governance-engine/run-orchestrator.ts`

---

### 5. Metrics Dashboard (12 hours)

**Problem:** Metrics exist, not visualized

**Three Dashboards:**

1. **Provider Metrics** - From GitHub/GitLab
   - PR cycle time
   - Review latency
   - Merge frequency
   - Failed PR ratio

2. **ReadyLayer Metrics** - Internal
   - LLM call latency
   - Cache hit rate
   - Queue depth
   - Worker throughput

3. **Proof of Value** - Customer-facing
   - Bugs prevented
   - Time saved
   - Cost saved
   - Compliance violations avoided

**Implementation:**
```typescript
// app/dashboard/metrics/provider/page.tsx
// app/dashboard/metrics/readylayer/page.tsx
// app/dashboard/metrics/proof/page.tsx
```

---

### 6. Accessibility Compliance (24 hours)

**Problem:** Only 61 accessibility attributes, not WCAG 2.1 AA compliant

**Current State:**
```bash
# Grep results
aria-*: 38 instances
role=*: 15 instances
alt=*: 8 instances
```

**WCAG 2.1 AA Requirements:**
- Keyboard navigation ❌
- Screen reader support ❌
- Focus indicators ❌
- Color contrast 4.5:1 ❌
- ARIA labels ❌
- Skip links ❌
- Heading hierarchy ❌

**Action Plan:**

**Week 1: Audit** (8 hours)
1. ✅ Run axe-core on all pages
2. ✅ Test with NVDA screen reader
3. ✅ Test keyboard navigation
4. ✅ Check color contrast with WCAG checker
5. ✅ Document violations

**Week 2: Fix Components** (12 hours)
```typescript
// Example: Make Button accessible
export function Button({ onClick, children, ...props }) {
  return (
    <button
      onClick={onClick}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          onClick(e);
        }
      }}
      aria-label={props['aria-label'] || children}
      role="button"
      tabIndex={0}
      {...props}
    >
      {children}
    </button>
  );
}

// Add to all interactive elements
<div
  role="button"
  tabIndex={0}
  onKeyDown={handleKeyDown}
  aria-label="Close modal"
>
  <X />
</div>
```

**Week 3: Verify** (4 hours)
1. ✅ Re-run axe-core
2. ✅ User testing with screen reader users
3. ✅ Add to CI: `npm run test:a11y`

**Tools:**
- `eslint-plugin-jsx-a11y`
- `axe-core` for automated testing
- `react-aria` for accessible primitives

---

### 7. Performance Optimizations (16 hours)

**Current Performance:**
- First Contentful Paint: ~2.5s
- Time to Interactive: ~4.2s
- Largest Contentful Paint: ~3.8s

**Optimizations:**

**1. Component Memoization** (4 hours)
```typescript
// components/dashboard/RunCard.tsx
import { memo } from 'react';

export const RunCard = memo(function RunCard({ run }) {
  return (
    <Card>
      <RunStatus status={run.status} />
      <RunMetrics metrics={run.metrics} />
    </Card>
  );
}, (prev, next) => {
  // Only re-render if run ID changes
  return prev.run.id === next.run.id && prev.run.status === next.run.status;
});

// components/dashboard/ViolationTableRow.tsx
export const ViolationTableRow = memo(function ViolationTableRow({ violation }) {
  // ...
});
```

**2. Database Query Optimization** (6 hours)
```typescript
// Add eager loading
const reviews = await prisma.review.findMany({
  where: { repositoryId },
  include: {
    violations: true, // Prevent N+1
    repository: { select: { name: true, fullName: true } },
    user: { select: { name: true, avatarUrl: true } }
  },
  take: 50,
  orderBy: { createdAt: 'desc' }
});

// Add pagination
const [reviews, total] = await Promise.all([
  prisma.review.findMany({ skip, take }),
  prisma.review.count({ where })
]);
```

**3. CDN for Static Assets** (2 hours)
```typescript
// next.config.js
module.exports = {
  images: {
    loader: 'custom',
    domains: ['cdn.readylayer.com']
  },
  assetPrefix: process.env.NODE_ENV === 'production'
    ? 'https://cdn.readylayer.com'
    : ''
};
```

**4. Code Splitting** (4 hours)
```typescript
// Lazy load heavy components
const AdminPanel = lazy(() => import('@/components/admin/AdminPanel'));
const PolicyBuilder = lazy(() => import('@/components/admin/PolicyBuilder'));

<Suspense fallback={<Skeleton />}>
  <AdminPanel />
</Suspense>
```

**Reference:** `docs/COMPONENT-MEMOIZATION-AUDIT.md`, `docs/OPTIMIZATION-ROADMAP.md`

---

### 8. Missing API Endpoints (32 hours)

**Teams Management** (8 hours)
```typescript
// POST /api/v1/teams
// GET /api/v1/teams
// PUT /api/v1/teams/[teamId]
// DELETE /api/v1/teams/[teamId]
```

**Notification Preferences** (4 hours)
```typescript
// GET /api/v1/notifications/preferences
// PUT /api/v1/notifications/preferences
// POST /api/v1/notifications/test
```

**Webhook Management** (8 hours)
```typescript
// GET /api/v1/webhooks
// POST /api/v1/webhooks/test
// GET /api/v1/webhooks/[webhookId]/deliveries
```

**Audit Export** (4 hours)
```typescript
// GET /api/v1/audit/export?format=csv
// GET /api/v1/audit/verify
```

**Policy Simulation** (8 hours)
```typescript
// POST /api/v1/policies/simulate
// POST /api/v1/policies/impact
```

---

## Moat Strengthening

### Unique Competitive Advantages

**1. Governance Engine - Fully Implemented ✅**
**Strength:** Multi-model variance detection

**Evidence:**
- `services/governance-engine/run-orchestrator.ts` - Complete implementation
- Tracks: variance score, intent drift, confidence inflation, temporal fragility
- Database models: `GovernanceRun`, `GovernanceRunResult`, `IntentArtifact`

**Enhancement Opportunities:**
1. ✅ Add UI dashboard for variance visualization (P2, 16 hours)
2. ✅ Create variance alert system (4 hours)
3. ✅ Add variance-based auto-rollback (8 hours)
4. ✅ Build compliance reporting (4 hours)

---

**2. Policy-as-Code Inheritance ✅**
**Strength:** Org → Team → Repo policy chain

**Evidence:**
- `services/policy-engine/inheritance.ts` - Full implementation
- `services/policy-engine/templates.ts` - Template system
- Versioning with checksums for audit trails

**Enhancement Opportunities:**
1. ✅ Add policy diff visualization (6 hours)
2. ✅ Create policy impact analysis/preview mode (8 hours)
3. ✅ Build policy marketplace/community templates (16 hours)
4. ✅ Add policy migration tools (8 hours)

---

**3. Evidence Bundles - Partial ⚠️**
**Strength:** Audit trail for every decision

**Current:**
- Policy checksums ✅
- Input hashes ✅
- Rule versions ✅
- Cryptographic chaining ❌ (P1, 6 hours)

**Enhancement:**
1. ✅ Complete cryptographic chaining (P1)
2. ✅ Add tamper detection API
3. ✅ Create compliance export (SOC2, ISO)
4. ✅ Add blockchain anchoring (future)

---

**4. Async-First Architecture ✅**
**Strength:** Non-blocking HTTP responses

**Evidence:**
- Reviews return 202 with `enrichmentJobIds`
- Background workers process LLM calls
- Redis queue for job management

**Enhancement:**
1. ✅ Add WebSocket for real-time updates (12 hours)
2. ✅ Create progress indicators in UI (4 hours)
3. ✅ Add job prioritization (4 hours)

---

## Implementation Timeline

### Week 1: Critical Security (P0)
**Total: 42 hours (5 days @ 8 hours)**

**Day 1-2: Security Fixes**
- ✅ Secrets redaction (4 hours)
- ✅ Token encryption (4 hours)
- ✅ RLS policies (6 hours)
- ✅ Billing enforcement (2 hours)

**Day 3-4: Core Features**
- ✅ GitHub installation flow (6 hours)
- ✅ Cultural Artifacts decision (1 hour)
- ✅ Cultural Artifacts implementation OR downgrade (20 hours or 0 hours)

**Day 5: Testing & Verification**
- ✅ E2E tests for all P0 fixes
- ✅ Security audit
- ✅ Deploy to staging

---

### Weeks 2-3: High Priority (P1)
**Total: 54 hours (7 days @ 8 hours)**

**Week 2:**
- ✅ Resource-level authorization (3 hours)
- ✅ API key expiration (2 hours)
- ✅ Audit logging (4 hours)
- ✅ Cost tracking (3 hours)
- ✅ LLM caching (4 hours)
- ✅ Rate limiting (6 hours)
- ✅ Check-run annotations (4 hours)
- ✅ Deterministic governance (8 hours)

**Week 3:**
- ✅ Audit chain (6 hours)
- ✅ GitLab verification (8 hours)
- ✅ Bitbucket verification (8 hours)

---

### Weeks 4-7: Medium Priority (P2)
**Total: 128 hours (16 days @ 8 hours)**

**Week 4: Dashboards**
- ✅ Analytics dashboard (16 hours)
- ✅ Governance dashboard (16 hours)

**Week 5: Infrastructure**
- ✅ Test execution sandbox (24 hours)
- ✅ RAG vector search (8 hours)

**Week 6: Polish**
- ✅ Accessibility compliance (24 hours)
- ✅ Performance optimizations (16 hours)

**Week 7: API Completion**
- ✅ Missing API endpoints (32 hours)

---

## Success Metrics

### Pre-Launch (After P0 Fixes)
- ✅ 0 critical security vulnerabilities
- ✅ GitHub installation flow working
- ✅ Secrets redacted before LLM calls
- ✅ Tokens encrypted at rest
- ✅ RLS policies active
- ✅ Billing enforcement in webhooks
- ✅ Cultural Artifacts decision made

### Post-P1 (After 3 Weeks)
- ✅ All API routes have resource authorization
- ✅ LLM cache hit rate > 40%
- ✅ Avg API response time < 200ms
- ✅ Check-run annotations visible in GitHub
- ✅ Audit chain verifiable
- ✅ GitLab/Bitbucket tested end-to-end

### Post-P2 (After 7 Weeks)
- ✅ WCAG 2.1 AA compliant
- ✅ Test execution sandbox active
- ✅ RAG enabled by default
- ✅ Analytics dashboard launched
- ✅ First Contentful Paint < 1.5s
- ✅ All missing API endpoints implemented

---

## Risk Mitigation

### High Risk Items

**1. Cultural Artifacts Decision**
- **Risk:** Customer disappointment if removed
- **Mitigation:** Frame as "Beta" if incomplete, "Coming Soon" if removed
- **Decision Deadline:** End of Week 1

**2. Test Execution Sandbox**
- **Risk:** Docker infrastructure complexity
- **Mitigation:** Phase implementation, start with simple languages
- **Fallback:** Mark as "Premium" feature, delay to post-launch

**3. Accessibility Compliance**
- **Risk:** 24 hours may be insufficient
- **Mitigation:** Hire a11y consultant, use react-aria library
- **Fallback:** Fix critical issues, defer full compliance to P3

---

## Conclusion

ReadyLayer has a **strong foundation** (70+ models, 23+ services, 82% test coverage) but critical gaps prevent production launch. Addressing P0 issues (42 hours) will enable MVP launch. P1 fixes (54 hours) will ensure enterprise readiness. P2 enhancements (128 hours) will create competitive differentiation.

**Recommended Path:**
1. **Week 1:** Fix all P0 security and core feature blockers
2. **Week 2-3:** Complete P1 for enterprise readiness
3. **Week 4-7:** Implement P2 for competitive moat
4. **Month 2:** Focus on growth, integrations, enterprise features

**Total Investment:** 224 hours (~6 weeks with 1 engineer)

**Expected Outcome:** Production-ready platform with strong moat and enterprise capabilities.
