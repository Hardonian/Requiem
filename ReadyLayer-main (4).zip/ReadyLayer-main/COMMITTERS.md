# Committers & Maintainers

This document lists the current committers and maintainers of the ReadyLayer project.

**ReadyLayer is open source first.** Commit access is granted to community members who demonstrate sustained, high-quality contributions and alignment with project values.

---

## Core Maintainers

Core maintainers have full commit access, merge authority, and participate in governance decisions.

| Name | GitHub | Role | Focus Area | Since |
|------|--------|------|------------|-------|
| **[To Be Updated]** | [@Hardonian](https://github.com/Hardonian) | Lead Maintainer | Architecture, Governance | 2025 |
| **[To Be Updated]** | [@TBD](https://github.com) | Core Maintainer | Security, Infrastructure | 2025 |

---

## Committers

Committers have merge access for specific areas and review authority for their domain.

| Name | GitHub | Focus Area | Since |
|------|--------|------------|-------|
| *No additional committers yet* | — | — | — |

---

## Emeritus Maintainers

Former maintainers who have stepped down but remain valued contributors to the project.

| Name | GitHub | Contributions | Active Period |
|------|--------|---------------|---------------|
| *None yet* | — | — | — |

---

## How to Become a Committer

ReadyLayer grants commit access based on merit, not affiliation. We follow these principles:

### Path to Committer Status

1. **Sustained Contribution** (3+ months)
   - Regular, high-quality PRs
   - Code reviews on others' PRs
   - Community engagement (Discussions, Issues)

2. **Domain Expertise**
   - Deep knowledge in specific area (security, testing, documentation, etc.)
   - Demonstrates architectural understanding
   - Writes maintainable, well-tested code

3. **Cultural Alignment**
   - Follows [CODE_OF_CONDUCT.md](./CODE_OF_CONDUCT.md)
   - Collaborative, respectful communication
   - Prioritizes project health over personal preferences

4. **Trust & Reliability**
   - Responds to feedback constructively
   - Delivers on commitments
   - Makes decisions aligned with project values

### Nomination Process

1. **Existing maintainer nominates candidate** in private discussion
2. **All core maintainers vote** (majority approval required)
3. **Candidate is invited** with defined scope (full commit vs. area-specific)
4. **Onboarding period** (30 days with mentor)
5. **Full committer status** after successful onboarding

### Expectations for Committers

- **Code Review**: Review PRs in your area within 48 hours
- **Mentorship**: Help new contributors onboard
- **Governance**: Participate in technical decisions
- **Community**: Engage in Discussions, answer questions
- **Conflict of Interest**: Disclose any conflicts proactively

---

## Maintainer Responsibilities

### All Maintainers Must

- ✅ **Follow the Release Process**: See [docs/RELEASE_PROCESS.md](./docs/RELEASE_PROCESS.md)
- ✅ **Enforce Code Standards**: Require tests, type safety, linting
- ✅ **Review Security PRs**: Security changes require 2+ maintainer reviews
- ✅ **Maintain Documentation**: Keep docs aligned with code changes
- ✅ **Respond to Security Reports**: See [SECURITY.md](./SECURITY.md)
- ✅ **Preserve OSS Values**: See [docs/WHY_OPEN_SOURCE.md](./docs/WHY_OPEN_SOURCE.md)

### Lead Maintainer Responsibilities

- Set project direction and technical vision
- Resolve disputes and tie-breaking votes
- Manage releases and versioning
- Coordinate with Enterprise Cloud team (if applicable)
- Enforce OSS/Enterprise boundary (see [docs/OSS_VS_ENTERPRISE_BOUNDARY.md](./docs/OSS_VS_ENTERPRISE_BOUNDARY.md))

---

## Stepping Down

Maintainers can step down at any time, no questions asked. We recognize that life circumstances change.

**To step down:**
1. Notify other maintainers (email or private discussion)
2. Transfer active PRs/issues to another maintainer
3. Remove your access (or request removal)
4. Move to Emeritus list with honor

**Emeritus maintainers:**
- Retain recognition in project history
- Can return to active status without re-application
- Welcome to contribute at any capacity

---

## Conflict of Interest Policy

### Commercial Interests

- **Disclosure Required**: Maintainers must disclose employment or financial interest in companies that:
  - Use ReadyLayer in production
  - Offer competing products
  - Provide related services

- **Recusal**: Maintainers must recuse themselves from decisions where conflict exists

### Enterprise Cloud

- Maintainers affiliated with Enterprise Cloud offerings must:
  - Prioritize OSS health over commercial interests
  - Ensure feature parity (see [docs/OSS_VS_ENTERPRISE_BOUNDARY.md](./docs/OSS_VS_ENTERPRISE_BOUNDARY.md))
  - Disclose commercial roadmap conflicts

---

## Removal of Commit Access

Commit access may be revoked for:

- **Inactivity**: No commits or reviews for 12+ months (can be reinstated)
- **Code of Conduct Violations**: Serious or repeated violations
- **Security Violations**: Intentional introduction of vulnerabilities
- **Abuse of Access**: Using commit rights inappropriately

**Process:**
1. Private discussion among core maintainers
2. Unanimous vote required for removal
3. Notification to affected maintainer
4. Public announcement (if warranted)

---

## Contact

- **General Questions**: [GitHub Discussions](https://github.com/Hardonian/ReadyLayer/discussions)
- **Maintainer Nomination**: Email opensource@readylayer.io
- **Governance Questions**: See [docs/GOVERNANCE.md](./docs/GOVERNANCE.md)

---

## Acknowledgments

ReadyLayer exists because of sustained contributions from maintainers and the broader community. We're grateful to everyone who has reviewed code, filed issues, answered questions, and improved the project.

**Thank you for making ReadyLayer trustworthy, inspectable, and useful.** 🎉

---

<div align="center">

**Want to become a committer?** Start by reviewing [CONTRIBUTING.md](./CONTRIBUTING.md)

</div>
