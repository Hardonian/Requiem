import { redirect } from 'next/navigation'

export default function MarketplaceIntegrationsRedirectPage(): void {
  redirect('/integrations')
}
