import { redirect } from 'next/navigation'

export default function MarketplacePoliciesRedirectPage(): void {
  redirect('/governance')
}
