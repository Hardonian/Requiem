import { redirect } from 'next/navigation'

export default function MarketplaceRedirectPage(): void {
  redirect('/integrations')
}
