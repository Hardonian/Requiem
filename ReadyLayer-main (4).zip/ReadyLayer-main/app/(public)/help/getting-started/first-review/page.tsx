import { redirect } from 'next/navigation'

export default function FirstReviewRedirectPage(): void {
  redirect('/docs')
}
