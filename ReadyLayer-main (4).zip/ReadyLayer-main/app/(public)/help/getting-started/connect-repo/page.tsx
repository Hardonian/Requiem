import { redirect } from 'next/navigation'

export default function ConnectRepoRedirectPage(): void {
  redirect('/docs')
}
