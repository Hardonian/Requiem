import { redirect } from 'next/navigation'

export default function OSSMaintainersRedirectPage(): void {
  redirect('/open-source')
}
