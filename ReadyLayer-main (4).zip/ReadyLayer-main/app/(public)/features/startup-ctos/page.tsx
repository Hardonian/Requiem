import { redirect } from 'next/navigation'

export default function StartupCtosRedirectPage(): void {
  redirect('/open-source')
}
