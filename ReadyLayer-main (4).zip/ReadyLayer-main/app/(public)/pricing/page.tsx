import { redirect } from 'next/navigation'

export default function PricingRedirectPage(): void {
  redirect('/enterprise')
}
