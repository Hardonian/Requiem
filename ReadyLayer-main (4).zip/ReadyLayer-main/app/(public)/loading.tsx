import { LoadingState } from '@/components/ui'

export default function Loading(): React.JSX.Element {
  return <LoadingState message="Loading the latest details..." />
}
