import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { logger } from '../../../../observability/logging';
import { metrics } from '../../../../observability/metrics';
import Stripe from 'stripe';
import { z } from 'zod';

// Webhook routes must use Node runtime for signature verification and raw body access
export const runtime = 'nodejs';

export const StripeEventSchema = z.object({
  id: z.string(),
  type: z.string(),
  data: z.object({
    object: z.unknown(),
  }),
}).passthrough();

const StripeSubscriptionSchema = z.object({
  id: z.string(),
  customer: z.union([z.string(), z.object({ id: z.string() })]),
  status: z.string(),
  items: z.object({
    data: z.array(
      z.object({
        price: z.object({
          metadata: z.record(z.string(), z.string()).optional(),
        }),
      }).passthrough()
    ),
  }),
  current_period_start: z.number(),
  current_period_end: z.number(),
  cancel_at_period_end: z.boolean().optional(),
}).passthrough();

const StripeInvoiceSchema = z.object({
  id: z.string(),
  customer: z.union([z.string(), z.object({ id: z.string() })]),
  subscription: z.union([z.string(), z.object({ id: z.string() }).passthrough(), z.null()]).optional(),
}).passthrough();

const StripeCheckoutSessionSchema = z.object({
  id: z.string(),
}).passthrough();

// Initialize Stripe client
let stripe: Stripe | null = null;

interface StripeSubscriptionWithPeriod extends Stripe.Subscription {
  current_period_start: number;
  current_period_end: number;
}

interface StripeInvoiceWithSubscription extends Stripe.Invoice {
  subscription: StripeSubscriptionWithPeriod | string | null;
}

function getStripeClient(): Stripe {
  if (!stripe) {
    const secretKey = process.env.STRIPE_SECRET_KEY;
    if (!secretKey) {
      throw new Error('STRIPE_SECRET_KEY environment variable is required. Please configure Stripe in your environment.');
    }
    stripe = new Stripe(secretKey, {
      apiVersion: '2023-10-16' as Stripe.LatestApiVersion,
    });
  }
  return stripe;
}

/**
 * Check if Stripe is configured
 */
function isStripeConfigured(): boolean {
  return !!process.env.STRIPE_SECRET_KEY && !!process.env.STRIPE_WEBHOOK_SECRET;
}

/**
 * Verify Stripe webhook signature
 */
function verifySignature(
  payload: string,
  signature: string,
  secret: string
): Stripe.Event | null {
  try {
    const stripe = getStripeClient();
    return stripe.webhooks.constructEvent(payload, signature, secret);
  } catch (error) {
    logger.error({ error }, 'Stripe webhook signature verification failed');
    return null;
  }
}

/**
 * POST /api/webhooks/stripe
 * Handle Stripe webhooks
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  const requestId = request.headers.get('x-request-id') || `stripe_${Date.now()}`;
  const log = logger.child({ requestId });

  try {
    // Check if Stripe is configured
    if (!isStripeConfigured()) {
      log.warn('Stripe webhook received but Stripe is not configured');
      return NextResponse.json(
        {
          error: {
            code: 'STRIPE_NOT_CONFIGURED',
            message: 'Stripe is not configured. Please set STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET environment variables.',
          },
        },
        { status: 503 }
      );
    }

    const signature = request.headers.get('stripe-signature');
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!signature || !webhookSecret) {
      return NextResponse.json(
        {
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Missing required headers: stripe-signature or STRIPE_WEBHOOK_SECRET not configured',
          },
        },
        { status: 400 }
      );
    }

    // Get raw body for signature verification
    const payload = await request.text();

    // Verify signature
    const event = verifySignature(payload, signature, webhookSecret);
    if (!event) {
      return NextResponse.json(
        {
          error: {
            code: 'INVALID_SIGNATURE',
            message: 'Invalid webhook signature',
          },
        },
        { status: 400 }
      );
    }
    const parsedEvent = StripeEventSchema.safeParse(event);
    if (!parsedEvent.success) {
      log.warn({ issues: parsedEvent.error.issues }, 'Stripe webhook payload validation failed');
      return NextResponse.json(
        {
          error: {
            code: 'INVALID_EVENT',
            message: 'Webhook payload validation failed',
          },
        },
        { status: 400 }
      );
    }

    log.info({ eventType: event.type }, 'Received Stripe webhook');

    // Handle event based on type
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        {
          const subscriptionParsed = StripeSubscriptionSchema.safeParse(event.data.object);
          if (!subscriptionParsed.success) {
            log.warn({ issues: subscriptionParsed.error.issues }, 'Invalid subscription payload');
            return NextResponse.json(
              { error: { code: 'INVALID_SUBSCRIPTION', message: 'Invalid subscription payload' } },
              { status: 400 }
            );
          }
          // Cast is safe here - data comes from Stripe webhook and we've validated required fields
          await handleSubscriptionChange(event.data.object as Stripe.Subscription);
        }
        break;

      case 'customer.subscription.deleted':
        {
          const subscriptionParsed = StripeSubscriptionSchema.safeParse(event.data.object);
          if (!subscriptionParsed.success) {
            log.warn({ issues: subscriptionParsed.error.issues }, 'Invalid subscription payload');
            return NextResponse.json(
              { error: { code: 'INVALID_SUBSCRIPTION', message: 'Invalid subscription payload' } },
              { status: 400 }
            );
          }
          // Cast is safe here - data comes from Stripe webhook and we've validated required fields
          await handleSubscriptionDeleted(event.data.object as Stripe.Subscription);
        }
        break;

      case 'invoice.payment_succeeded':
        {
          const invoiceParsed = StripeInvoiceSchema.safeParse(event.data.object);
          if (!invoiceParsed.success) {
            log.warn({ issues: invoiceParsed.error.issues }, 'Invalid invoice payload');
            return NextResponse.json(
              { error: { code: 'INVALID_INVOICE', message: 'Invalid invoice payload' } },
              { status: 400 }
            );
          }
          // Cast is safe here - data comes from Stripe webhook and we've validated required fields
          await handleInvoicePaymentSucceeded(event.data.object as Stripe.Invoice);
        }
        break;

      case 'invoice.payment_failed':
        {
          const invoiceParsed = StripeInvoiceSchema.safeParse(event.data.object);
          if (!invoiceParsed.success) {
            log.warn({ issues: invoiceParsed.error.issues }, 'Invalid invoice payload');
            return NextResponse.json(
              { error: { code: 'INVALID_INVOICE', message: 'Invalid invoice payload' } },
              { status: 400 }
            );
          }
          // Cast is safe here - data comes from Stripe webhook and we've validated required fields
          await handleInvoicePaymentFailed(event.data.object as Stripe.Invoice);
        }
        break;

      case 'checkout.session.completed':
        {
          const sessionParsed = StripeCheckoutSessionSchema.safeParse(event.data.object);
          if (!sessionParsed.success) {
            log.warn({ issues: sessionParsed.error.issues }, 'Invalid checkout session payload');
            return NextResponse.json(
              { error: { code: 'INVALID_SESSION', message: 'Invalid checkout session payload' } },
              { status: 400 }
            );
          }
          // Cast is safe here - data comes from Stripe webhook and we've validated required fields
          await handleCheckoutCompleted(event.data.object as Stripe.Checkout.Session);
        }
        break;

      default:
        log.warn({ eventType: event.type }, 'Unhandled Stripe webhook event type');
    }

    metrics.increment('webhooks.received', { provider: 'stripe', event: event.type });

    return NextResponse.json({ received: true }, { status: 200 });
  } catch (error) {
    log.error(error, 'Stripe webhook handling failed');
    metrics.increment('webhooks.failed', { provider: 'stripe' });

    return NextResponse.json(
      {
        error: {
          code: 'WEBHOOK_FAILED',
          message: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      { status: 500 }
    );
  }
}

/**
 * Handle subscription created/updated
 */
async function handleSubscriptionChange(subscription: Stripe.Subscription): Promise<void> {
  const log = logger.child({ subscriptionId: subscription.id });

  try {
    const customerId = typeof subscription.customer === 'string'
      ? subscription.customer
      : (subscription.customer as Stripe.Customer).id;

    // Find organization by Stripe customer ID
    const org = await prisma.organization.findFirst({
      where: {
        subscriptions: {
          some: {
            stripeCustomerId: customerId,
          },
        },
      },
      include: {
        subscriptions: true,
      },
    });

    if (!org) {
      log.warn({ customerId }, 'Organization not found for Stripe customer');
      return;
    }

    // Determine plan from subscription metadata or price ID
    let plan: 'starter' | 'growth' | 'scale' = 'starter';
    if (subscription.items.data.length > 0) {
      // Map Stripe price IDs to plans (configure in Stripe dashboard)
      // For now, use metadata or price lookup
      const priceMetadata = subscription.items.data[0].price.metadata;
      if (priceMetadata?.plan) {
        plan = priceMetadata.plan as 'starter' | 'growth' | 'scale';
      }
    }

    // Update or create subscription
    const existingSubscription = org.subscriptions[0];

    if (existingSubscription) {
      const sub = subscription as StripeSubscriptionWithPeriod;
      await prisma.subscription.update({
        where: { id: existingSubscription.id },
        data: {
          plan,
          status: mapStripeStatus(subscription.status),
          stripeSubscriptionId: subscription.id,
          currentPeriodStart: new Date(sub.current_period_start * 1000),
          currentPeriodEnd: new Date(sub.current_period_end * 1000),
          cancelAtPeriodEnd: subscription.cancel_at_period_end || false,
          updatedAt: new Date(),
        },
      });
    } else {
      // Get user ID from organization (use first owner/admin)
      const owner = await prisma.organizationMember.findFirst({
        where: {
          organizationId: org.id,
          role: { in: ['owner', 'admin'] },
        },
      });

      if (!owner) {
        log.warn({ organizationId: org.id }, 'No owner/admin found for organization');
        return;
      }

      const sub = subscription as StripeSubscriptionWithPeriod;
      await prisma.subscription.create({
        data: {
          organizationId: org.id,
          userId: owner.userId,
          plan,
          status: mapStripeStatus(subscription.status),
          stripeCustomerId: customerId,
          stripeSubscriptionId: subscription.id,
          currentPeriodStart: new Date(sub.current_period_start * 1000),
          currentPeriodEnd: new Date(sub.current_period_end * 1000),
          cancelAtPeriodEnd: subscription.cancel_at_period_end || false,
        },
      });
    }

    // Update organization plan
    await prisma.organization.update({
      where: { id: org.id },
      data: { plan },
    });

    log.info({ organizationId: org.id, plan }, 'Subscription updated');
  } catch (error) {
    log.error(error, 'Failed to handle subscription change');
    throw error;
  }
}

/**
 * Handle subscription deleted
 */
async function handleSubscriptionDeleted(subscription: Stripe.Subscription): Promise<void> {
  const log = logger.child({ subscriptionId: subscription.id });

  try {
    const customerId = typeof subscription.customer === 'string'
      ? subscription.customer
      : (subscription.customer as Stripe.Customer).id;

    // Find and update subscription
    const dbSubscription = await prisma.subscription.findFirst({
      where: {
        stripeSubscriptionId: subscription.id,
        stripeCustomerId: customerId,
      },
      include: {
        organization: true,
      },
    });

    if (!dbSubscription) {
      log.warn({ subscriptionId: subscription.id }, 'Subscription not found');
      return;
    }

    // Update subscription status
    await prisma.subscription.update({
      where: { id: dbSubscription.id },
      data: {
        status: 'cancelled',
        updatedAt: new Date(),
      },
    });

    // Downgrade organization to starter
    await prisma.organization.update({
      where: { id: dbSubscription.organizationId },
      data: { plan: 'starter' },
    });

    log.info({ organizationId: dbSubscription.organizationId }, 'Subscription cancelled, downgraded to starter');
  } catch (error) {
    log.error(error, 'Failed to handle subscription deletion');
    throw error;
  }
}

/**
 * Handle invoice payment succeeded
 */
async function handleInvoicePaymentSucceeded(invoice: Stripe.Invoice): Promise<void> {
  const log = logger.child({ invoiceId: invoice.id });

  try {
    if (!invoice.customer) {
      log.warn({ invoiceId: invoice.id }, 'Invoice has no customer');
      return;
    }
    const customerId = typeof invoice.customer === 'string'
      ? invoice.customer
      : (invoice.customer as Stripe.Customer).id;

    // Find subscription
    const subscription = await prisma.subscription.findFirst({
      where: {
        stripeCustomerId: customerId,
      },
    });

    if (subscription) {
      // Update subscription period if needed
      const inv = invoice as StripeInvoiceWithSubscription;
      if (inv.subscription && typeof inv.subscription !== 'string') {
        const stripeSubscription = inv.subscription as StripeSubscriptionWithPeriod;
        await prisma.subscription.update({
          where: { id: subscription.id },
          data: {
            currentPeriodStart: new Date(stripeSubscription.current_period_start * 1000),
            currentPeriodEnd: new Date(stripeSubscription.current_period_end * 1000),
            status: 'active',
            updatedAt: new Date(),
          },
        });
      }

      log.info({ subscriptionId: subscription.id }, 'Invoice payment succeeded');
    }
  } catch (error) {
    log.error(error, 'Failed to handle invoice payment succeeded');
    // Don't throw - payment succeeded, just logging failed
  }
}

/**
 * Handle invoice payment failed
 */
async function handleInvoicePaymentFailed(invoice: Stripe.Invoice): Promise<void> {
  const log = logger.child({ invoiceId: invoice.id });

  try {
    if (!invoice.customer) {
      log.warn({ invoiceId: invoice.id }, 'Invoice has no customer');
      return;
    }
    const customerId = typeof invoice.customer === 'string'
      ? invoice.customer
      : (invoice.customer as Stripe.Customer).id;

    // Find subscription
    const subscription = await prisma.subscription.findFirst({
      where: {
        stripeCustomerId: customerId,
      },
    });

    if (subscription) {
      // Update subscription status
      await prisma.subscription.update({
        where: { id: subscription.id },
        data: {
          status: 'expired',
          updatedAt: new Date(),
        },
      });

      // Downgrade organization to starter
      await prisma.organization.update({
        where: { id: subscription.organizationId },
        data: { plan: 'starter' },
      });

      log.info({ subscriptionId: subscription.id }, 'Invoice payment failed, downgraded to starter');
    }
  } catch (error) {
    log.error(error, 'Failed to handle invoice payment failed');
    // Don't throw - payment failed is expected, just logging failed
  }
}

/**
 * Handle checkout session completed
 */
async function handleCheckoutCompleted(session: Stripe.Checkout.Session): Promise<void> {
  const log = logger.child({ sessionId: session.id });

  try {
    if (session.mode !== 'subscription' || !session.subscription) {
      log.warn({ mode: session.mode }, 'Checkout session is not a subscription');
      return;
    }

    const customerId = typeof session.customer === 'string'
      ? session.customer
      : session.customer?.id;

    if (!customerId) {
      log.warn({ sessionId: session.id }, 'No customer ID in checkout session');
      return;
    }

    // Get organization ID from metadata
    const organizationId = session.metadata?.organizationId;
    if (!organizationId) {
      log.warn({ sessionId: session.id }, 'No organizationId in checkout session metadata');
      return;
    }

    // Get subscription from Stripe
    const stripe = getStripeClient();
    const subscription = await stripe.subscriptions.retrieve(
      typeof session.subscription === 'string' ? session.subscription : session.subscription.id
    );

    // Handle subscription creation
    await handleSubscriptionChange(subscription);

    log.info({ organizationId, subscriptionId: subscription.id }, 'Checkout completed, subscription created');
  } catch (error) {
    log.error(error, 'Failed to handle checkout completed');
    throw error;
  }
}

/**
 * Map Stripe subscription status to internal status
 */
function mapStripeStatus(stripeStatus: Stripe.Subscription.Status): 'active' | 'cancelled' | 'expired' | 'trialing' {
  switch (stripeStatus) {
    case 'active':
      return 'active';
    case 'canceled':
    case 'unpaid':
      return 'cancelled';
    case 'past_due':
    case 'incomplete_expired':
      return 'expired';
    case 'trialing':
      return 'trialing';
    default:
      return 'active'; // Default to active for unknown statuses
  }
}
 
