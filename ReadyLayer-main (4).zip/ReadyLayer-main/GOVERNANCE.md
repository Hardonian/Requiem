# ReadyLayer Governance

ReadyLayer is a maintainer-led open-source project. The maintainers are responsible for the roadmap, release decisions, and project stewardship.

## Decision Making
- Changes are proposed via GitHub Issues or Pull Requests.
- Maintainers review proposals for scope, safety, and alignment with project goals.
- Significant changes should be discussed in GitHub Discussions before implementation.

## Maintainers
See [COMMITTERS.md](./COMMITTERS.md) for the current list of maintainers and committers.

## Community Input
We welcome feedback and proposals from the community. Use discussions for early design input and issues for actionable work items.

## Code of Conduct
All participants must follow the [Code of Conduct](./CODE_OF_CONDUCT.md).
