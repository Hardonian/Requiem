# Support

Thanks for using ReadyLayer. This project is community-supported; the maintainer team reviews issues and discussions as capacity allows.

## Get Help
- **Questions and how-to:** use [GitHub Discussions](https://github.com/Hardonian/ReadyLayer/discussions).
- **Bug reports:** open a GitHub Issue using the bug report template.
- **Feature requests:** open a GitHub Issue using the feature request template.

## Security Issues
Please do **not** file public issues for security vulnerabilities. Follow the instructions in [SECURITY.md](./SECURITY.md).

## Response Expectations
We aim to acknowledge new issues and discussions within a few business days. Complex investigations or roadmap requests may take longer.
