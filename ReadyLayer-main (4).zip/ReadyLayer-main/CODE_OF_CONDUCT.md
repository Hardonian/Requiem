# Contributor Covenant Code of Conduct

## Our Commitment

We are committed to providing a welcoming and inspiring community for all. We pledge that everyone participating in the ReadyLayer project and community will be treated with respect and dignity.

## Our Standards

### Positive Behavior Examples
- Using welcoming and inclusive language
- Being respectful of differing opinions and experiences
- Accepting constructive criticism gracefully
- Focusing on what is best for the community
- Showing empathy toward other community members
- Helping new contributors get up to speed
- Sharing knowledge and experience

### Unacceptable Behavior
- Harassment, discrimination, or hate speech
- Insults, derogatory comments, or personal attacks
- Public or private harassment
- Publishing private information without consent
- Trolling or flame wars
- Spam or self-promotion
- Any conduct that could reasonably be considered inappropriate in a professional setting

## Enforcement

### Reporting
If you experience or witness unacceptable behavior:

1. **Document the incident** — Save relevant messages/screenshots
2. **Report privately** — Email hello@readylayer.io with details
3. **Include context** — Who, what, when, where, why
4. **Stay safe** — Never confront harassers yourself

### Response
- We will investigate all reports
- Confidentiality will be maintained
- Action will be taken if violation is confirmed
- Repeat offenders may be permanently banned

### Consequences
Maintainers may take any action they deem appropriate:
1. Warning and discussion
2. Temporary ban from community
3. Permanent ban from community
4. Removal from contributor lists

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.

## Questions?

Contact: hello@readylayer.io

---

We're committed to creating a safe, inclusive community. Thank you for helping make it a welcoming place for everyone.
